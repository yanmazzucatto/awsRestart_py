comida = ["frango","arroz","feijao","salada"]
for produto in comida:
    if produto == "frango":
        print(produto,produto)
    else:
        print(produto)