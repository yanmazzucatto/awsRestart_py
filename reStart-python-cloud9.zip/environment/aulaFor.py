listaNomes = ["pedro","carlos","joao"]
for nome in listaNomes:
    print("Ola "+nome)
    
print("ola {}, ola {}, ola {}".format(listaNomes[0],listaNomes[1],listaNomes[2]))


for nome in listaNomes:
    print("Ola "+nome+" prazer em conhece-lo")
    
    

myMixedTypeList = [45, 290578, 1.02, True, "My dog is on the bed.", "45"]
for item in myMixedTypeList:
    print("{} is of the data type {}".format(item,type(item)))