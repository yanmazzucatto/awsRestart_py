name = input("what's your name?  ")

team = input("which are your favorite team in the NBA?   ")

print("prazer {}, e voce torce pro {}".format(name,team))

locais = {
    "pais":"canada"
    ,"cidade":"campinas"
    ,"rua":"rua quinze"
}


nome=["pedro", "carlos", "joao"]

print(nome[2])

print(locais['cidade'])

 
locais['cidade'] = "maringa"
print(locais['cidade'])
del locais['rua']

print(locais)